
import { useState, useEffect } from 'react';
import jsPDF from 'jspdf';

export default function App() {
  const [language, setLanguage] = useState(null);
  const [step, setStep] = useState('menu');
  const [candidateId, setCandidateId] = useState('');
  const [colorWord, setColorWord] = useState('');
  const [displayColor, setDisplayColor] = useState('');
  const [score, setScore] = useState(0);
  const [timer, setTimer] = useState(0);
  const [errors, setErrors] = useState([]);

  const TEST_DURATION = 240;
  const colors = ['red','blue','green','yellow'];

  const start = ()=>{
    if(!candidateId) return;
    setScore(0); setErrors([]); setTimer(0);
    next(); setStep('test');
  };

  const next = ()=>{
    const w = colors[Math.floor(Math.random()*colors.length)];
    const c = colors[Math.floor(Math.random()*colors.length)];
    setColorWord(w); setDisplayColor(c);
  };

  useEffect(()=>{
    if(step!=='test') return;
    if(timer>=TEST_DURATION){ generate(); setStep('menu'); return; }
    const id=setInterval(()=>setTimer(t=>t+1),1000);
    return ()=>clearInterval(id);
  },[step,timer]);

  const handle=(c)=>{
    if(c===displayColor) setScore(s=>s+1);
    else setErrors(e=>[...e,{time:timer,chosen:c,correct:displayColor}]);
    next();
  };

  const generate=()=>{
    const pdf=new jsPDF();
    pdf.text('Focus Test Rapport',10,10);
    pdf.text('Kandidaat ID: '+candidateId,10,20);
    pdf.text('Score: '+score,10,30);
    pdf.text('Fouten: '+errors.length,10,40);
    pdf.save('rapport.pdf');
  };

  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      {step==='menu' && (
        <>
          <h1>Focus Test</h1>
          <input placeholder='Kandidaat ID' value={candidateId} onChange={e=>setCandidateId(e.target.value)} />
          <button onClick={start}>Start</button>
        </>
      )}

      {step==='test' && (
        <>
          <h2>Tijd: {timer}s</h2>
          <h1 style={{color:displayColor}}>{colorWord.toUpperCase()}</h1>
          {colors.map(c=>(<button key={c} onClick={()=>handle(c)}>{c}</button>))}
          <p>Score: {score}</p>
          <p>Fouten: {errors.length}</p>
        </>
      )}
    </div>
  );
}
